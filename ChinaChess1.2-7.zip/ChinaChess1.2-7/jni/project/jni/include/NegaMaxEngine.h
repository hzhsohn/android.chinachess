
#ifndef __NEGA_MAX_ENGINE_H_
#define __NEGA_MAX_ENGINE_H_

#include "SearchEngineInterface.h"
#include "MoveGenerator.h"

BOOL NegaMax_SearchAGoodMove(BYTE position[MAX_ROW][MAX_COL]);

#endif
