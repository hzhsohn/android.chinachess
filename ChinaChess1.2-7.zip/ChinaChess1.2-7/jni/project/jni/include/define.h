/**
 * Data structure and macros
 */

#ifndef __DEFINE_H_
#define __DEFINE_H_

#include <stdlib.h>
#include <android/log.h>

typedef unsigned char BYTE;
typedef unsigned char BOOL;

#define TRUE	1
#define FALSE	0

#endif
