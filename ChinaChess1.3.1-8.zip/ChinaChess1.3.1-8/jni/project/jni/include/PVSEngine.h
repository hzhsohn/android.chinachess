
#ifndef __PVR_ENGINE_H_
#define __PVR_ENGINE_H_

#include "SearchEngineInterface.h"
#include "MoveGenerator.h"

BOOL PVS_SearchAGoodMove(BYTE position[MAX_ROW][MAX_COL]);

#endif
