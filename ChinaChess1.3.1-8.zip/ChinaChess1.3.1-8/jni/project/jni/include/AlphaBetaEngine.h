
#ifndef __ALPHA_BETA_ENGINE_H_
#define __ALPHA_BETA_ENGINE_H_

#include "SearchEngineInterface.h"
#include "MoveGenerator.h"

BOOL AlphaBeta_SearchAGoodMove(BYTE position[MAX_ROW][MAX_COL]);

#endif
