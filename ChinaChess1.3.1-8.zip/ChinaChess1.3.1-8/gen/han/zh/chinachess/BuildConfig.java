/** Automatically generated file. DO NOT MODIFY */
package han.zh.chinachess;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}